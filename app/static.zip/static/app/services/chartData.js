occupancyApp.factory('chartData', function(){
  return { 
  	data: []
   };
});