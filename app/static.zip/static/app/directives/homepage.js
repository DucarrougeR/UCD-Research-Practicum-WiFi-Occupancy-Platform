occupancyApp.directive('greeting', function() {

  return {
    templateUrl: 'static/app/templates/home.html'
  };
});